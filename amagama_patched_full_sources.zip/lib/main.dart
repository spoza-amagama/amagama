// 📄 lib/main.dart
//
// 🎮 Amagama — Entry Point
// ------------------------------------------------------------
// • Initializes game state, audio service, providers
// • Applies AmagamaTheme
// • Uses centralized routing (AppRoutes)
// ------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// 🧠 State
import 'state/index.dart';
import 'controllers/card_grid_controller.dart';

// 🎵 Audio
import 'services/audio/audio_service.dart';

// 🌍 Routing
import 'routes/index.dart';

// 🎨 Theme
import 'theme/index.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Preload audio at launch
  await AudioService().preloadAll();

  runApp(const AmagamaApp());
}

class AmagamaApp extends StatelessWidget {
  const AmagamaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => GameController()..init()),
        ChangeNotifierProvider(create: (_) => AudioControllerProvider()),
        ChangeNotifierProvider(create: (_) => CardGridController()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Amagama',
        theme: AmagamaTheme.light(),
        darkTheme: AmagamaTheme.dark(),
        initialRoute: AppRoutes.home,
        routes: AppRoutes.routes,
        onGenerateRoute: AppRoutes.onGenerate,
      ),
    );
  }
}
