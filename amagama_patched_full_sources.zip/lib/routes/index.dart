// 📄 lib/routes/index.dart
//
// 🚦 Central Route Registry for Amagama
// ------------------------------------------------------------
// • Defines named routes in one place
// • Clean, scalable, barrel-based
// • Used by MaterialApp and navigation code
//

import 'package:flutter/material.dart';

import 'package:amagama/screens/home_screen.dart';
import 'package:amagama/screens/play_screen.dart';
import 'package:amagama/screens/grownups_screen.dart';

class AppRoutes {
  static const String home = '/';
  static const String play = '/play';
  static const String grownups = '/grownups';

  static final Map<String, WidgetBuilder> routes = {
    home: (context) => const HomeScreen(),
    play: (context) => const PlayScreen(),
    grownups: (context) => const GrownupsScreen(),
  };

  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case play:
        return MaterialPageRoute(builder: (_) => const PlayScreen());
      case grownups:
        return MaterialPageRoute(builder: (_) => const GrownupsScreen());
      case home:
      default:
        return MaterialPageRoute(builder: (_) => const HomeScreen());
    }
  }
}
