// 📄 lib/screens/grownups_screen.dart
//
// 👨‍👩‍👧 Grown Ups Screen — PIN gate for settings & controls.

import 'package:flutter/material.dart';
import 'package:amagama/theme/index.dart';
import 'package:amagama/widgets/common/screen_header.dart';
import 'package:amagama/widgets/home/grownup_pin_dialog.dart';

class GrownupsScreen extends StatelessWidget {
  const GrownupsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AmagamaColors.background,
      body: SafeArea(
        child: Column(
          children: const [
            ScreenHeader(
              title: 'Grown Ups',
              subtitle: 'Settings & Controls',
              showLogo: false,
            ),
            Expanded(
              child: GrownUpPinDialog(isStandalone: true),
            ),
          ],
        ),
      ),
    );
  }
}
