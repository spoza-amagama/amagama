// 📄 lib/widgets/home/grownup_pin_dialog.dart
//
// 🔒 GrownUpPinDialog — Parental PIN gate with custom keypad.
//

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:amagama/theme/index.dart';

class GrownUpPinDialog extends StatefulWidget {
  final bool isStandalone;

  const GrownUpPinDialog({
    super.key,
    this.isStandalone = false,
  });

  @override
  State<GrownUpPinDialog> createState() => _GrownUpPinDialogState();
}

class _GrownUpPinDialogState extends State<GrownUpPinDialog>
    with SingleTickerProviderStateMixin {
  String _storedPin = '1234';
  String _enteredPin = '';

  late AnimationController _shake;
  late Animation<double> _shakeAnimation;

  @override
  void initState() {
    super.initState();
    _loadPin();
    _shake = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _shakeAnimation = Tween<double>(begin: 0, end: 12)
        .chain(CurveTween(curve: Curves.elasticIn))
        .animate(_shake);
  }

  Future<void> _loadPin() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _storedPin = prefs.getString('grownup_pin') ?? '1234';
    });
  }

  void _onKeyTap(String digit) {
    if (_enteredPin.length >= 4) return;
    setState(() {
      _enteredPin += digit;
    });
    if (_enteredPin.length == 4) {
      _validatePin();
    }
  }

  void _validatePin() {
    if (_enteredPin == _storedPin) {
      HapticFeedback.lightImpact();
      if (widget.isStandalone) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('PIN accepted')),
        );
      } else {
        Navigator.pop(context, true);
      }
    } else {
      HapticFeedback.heavyImpact();
      _shake.forward(from: 0);
      setState(() {
        _enteredPin = '';
      });
    }
  }

  void _onBackspace() {
    if (_enteredPin.isEmpty) return;
    setState(() {
      _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1);
    });
  }

  @override
  void dispose() {
    _shake.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final card = AnimatedBuilder(
      animation: _shakeAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(_shakeAnimation.value, 0),
          child: child,
        );
      },
      child: _buildPinDots(),
    );

    return LayoutBuilder(
      builder: (context, constraints) {
        final double maxWidth =
            constraints.maxWidth.clamp(280.0, 420.0).toDouble();
        final double keypadWidth = (maxWidth - 40).clamp(240.0, 360.0);

        final content = Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Enter Parental PIN',
              style: AmagamaTypography.sectionTitleStyle,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            card,
            const SizedBox(height: 24),
            _buildKeypad(keypadWidth),
          ],
        );

        if (widget.isStandalone) {
          return Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: maxWidth),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                child: content,
              ),
            ),
          );
        }

        return AlertDialog(
          backgroundColor: const Color(0xFFFFF8E1),
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          contentPadding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
          content: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxWidth),
            child: content,
          ),
        );
      },
    );
  }

  Widget _buildPinDots() {
    return FittedBox(
      fit: BoxFit.scaleDown,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(4, (i) {
          final filled = i < _enteredPin.length;
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 6),
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              color: filled ? AmagamaColors.primary : AmagamaColors.surface,
              borderRadius: BorderRadius.circular(50),
              border: Border.all(
                color: filled
                    ? AmagamaColors.primary
                    : AmagamaColors.textSecondary,
                width: 2,
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildKeypad(double width) {
    return SizedBox(
      width: width,
      child: GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 3,
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
        children: [
          ...List.generate(9, (i) => _keyButton((i + 1).toString())),
          const SizedBox.shrink(),
          _keyButton('0'),
          _backspaceButton(),
        ],
      ),
    );
  }

  Widget _keyButton(String digit) {
    return ElevatedButton(
      onPressed: () => _onKeyTap(digit),
      style: ElevatedButton.styleFrom(
        backgroundColor: AmagamaColors.surface,
        foregroundColor: AmagamaColors.textPrimary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        elevation: 0,
        minimumSize: const Size(60, 60),
        padding: EdgeInsets.zero,
      ),
      child: Text(
        digit,
        style: AmagamaTypography.sectionTitleStyle.copyWith(
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _backspaceButton() {
    return ElevatedButton(
      onPressed: _onBackspace,
      style: ElevatedButton.styleFrom(
        backgroundColor: AmagamaColors.surface,
        foregroundColor: AmagamaColors.textPrimary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        elevation: 0,
        minimumSize: const Size(60, 60),
        padding: EdgeInsets.zero,
      ),
      child: const Icon(Icons.backspace, size: 20),
    );
  }
}
