// 📄 lib/widgets/home/home_content.dart
//
// 🏡 HomeContent — main Home Screen body.
// Uses viewSentenceIndex for live scrolling updates.
// Smoothly animates carousel height based on sentence length.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:amagama/theme/index.dart';
import 'package:amagama/state/game_controller.dart';
import 'package:amagama/data/index.dart';

import 'package:amagama/widgets/home/grownup_pin_dialog.dart';
import 'package:amagama/widgets/home/home_sentence_carousel.dart';
import 'package:amagama/routes/index.dart';

class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    final game = context.watch<GameController>();

    // Safety: avoid RangeError while data is still loading.
    if (sentences.isEmpty ||
        game.progress.isEmpty ||
        game.currentSentenceIndex < 0 ||
        game.currentSentenceIndex >= game.progress.length ||
        game.viewSentenceIndex < 0 ||
        game.viewSentenceIndex >= sentences.length) {
      return const SizedBox.shrink();
    }

    final int viewIdx = game.viewSentenceIndex;
    final sentence = sentences[viewIdx];

    final int activeIdx = game.currentSentenceIndex;
    final int cyclesDone = game.progress[activeIdx].cyclesCompleted;
    final int cyclesTarget = game.cyclesTarget;

    final int rawLinesEstimate = (sentence.text.length / 32).ceil();
    final int lineCount = rawLinesEstimate.clamp(1, 3);

    const double baseHeight = 140;
    const double perExtraLine = 26;
    const double transformAllowance = 40;

    final int extraLines = lineCount - 1;
    final double targetHeight =
        baseHeight + extraLines * perExtraLine + transformAllowance;

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const SizedBox(height: AmagamaSpacing.md),
        TweenAnimationBuilder<double>(
          duration: const Duration(milliseconds: 260),
          curve: Curves.easeOutCubic,
          tween: Tween<double>(end: targetHeight),
          builder: (context, value, child) {
            return SizedBox(
              height: value,
              child: child,
            );
          },
          child: const HomeSentenceCarousel(),
        ),
        const SizedBox(height: AmagamaSpacing.lg),
        Text(
          "Sentence ${viewIdx + 1} of ${sentences.length}",
          style: AmagamaTypography.progressStyle,
        ),
        const SizedBox(height: AmagamaSpacing.xs),
        Text(
          "Cycles: $cyclesDone / $cyclesTarget",
          style: AmagamaTypography.progressStyle,
        ),
        const SizedBox(height: AmagamaSpacing.md),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.emoji_events, color: AmagamaColors.warning, size: 22),
            const SizedBox(width: 4),
            Text("Bronze", style: AmagamaTypography.smallLabelStyle),
            const SizedBox(width: 18),
            const Icon(Icons.emoji_events, color: Colors.grey, size: 22),
            const SizedBox(width: 4),
            Text("Silver", style: AmagamaTypography.smallLabelStyle),
            const SizedBox(width: 18),
            Icon(Icons.emoji_events, color: AmagamaColors.primary, size: 22),
            const SizedBox(width: 4),
            Text("Gold", style: AmagamaTypography.smallLabelStyle),
          ],
        ),
        const SizedBox(height: AmagamaSpacing.sm),
        Container(
          height: 12,
          margin: const EdgeInsets.symmetric(horizontal: 32),
          decoration: BoxDecoration(
            color: AmagamaColors.overlay(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: (cyclesDone / cyclesTarget).clamp(0.0, 1.0),
            child: Container(
              decoration: BoxDecoration(
                color: AmagamaColors.secondary,
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
        const SizedBox(height: AmagamaSpacing.xl),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AmagamaColors.secondary,
            padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(28),
            ),
          ),
          onPressed: () {
            Navigator.pushNamed(context, AppRoutes.play);
          },
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.play_arrow),
              const SizedBox(width: 8),
              Text("Play", style: AmagamaTypography.buttonStyle),
            ],
          ),
        ),
        const SizedBox(height: AmagamaSpacing.md),
        TextButton(
          style: TextButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(28),
            ),
            backgroundColor: AmagamaColors.surface,
          ),
          onPressed: () async {
            final ok = await showDialog<bool>(
              context: context,
              builder: (_) => const GrownUpPinDialog(),
            );
            if (ok == true) {
              Navigator.pushNamed(context, AppRoutes.grownups);
            }
          },
          child: Text(
            "Grown Ups",
            style: AmagamaTypography.buttonStyle.copyWith(
              color: AmagamaColors.textPrimary,
            ),
          ),
        ),
        const SizedBox(height: AmagamaSpacing.lg),
      ],
    );
  }
}
