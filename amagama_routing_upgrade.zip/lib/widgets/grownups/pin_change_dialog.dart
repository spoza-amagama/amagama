// 📄 lib/widgets/grownups/pin_change_dialog.dart
//
// 🔐 showPinChangeFlow — verifies old PIN, prompts for new,
// and stores in SharedPreferences under 'grownup_pin'.
// ------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:amagama/theme/index.dart';

Future<void> showPinChangeFlow(BuildContext context) async {
  final prefs = await SharedPreferences.getInstance();
  final storedPin = prefs.getString('grownup_pin') ?? '1234';

  // Verify current PIN
  final verified = await _pinDialog(
    context,
    title: 'Enter current PIN',
    validator: (input) =>
        input == storedPin ? null : 'Incorrect PIN. Try again.',
  );
  if (verified == null) return;

  // Enter new PIN
  final newPin = await _pinDialog(
    context,
    title: 'Enter new PIN',
    validator: (input) =>
        input.length == 4 ? null : 'PIN must be 4 digits.',
  );
  if (newPin == null) return;

  await prefs.setString('grownup_pin', newPin);

  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(
      content: Text('Parental PIN updated'),
      backgroundColor: Colors.green,
    ),
  );
}

Future<String?> _pinDialog(
  BuildContext context, {
  required String title,
  required String? Function(String) validator,
}) {
  final controller = TextEditingController();
  String? error;
  bool obscure = true;

  return showDialog<String>(
    context: context,
    barrierDismissible: false,
    builder: (_) {
      return StatefulBuilder(
        builder: (context, setState) {
          void submit() {
            final text = controller.text.trim();
            final v = validator(text);
            if (v != null) {
              setState(() => error = v);
              return;
            }
            Navigator.pop(context, text);
          }

          return AlertDialog(
            backgroundColor: const Color(0xFFFFF8E1),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: Text(title, style: AmagamaTypography.sectionTitleStyle),
            content: TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              obscureText: obscure,
              maxLength: 4,
              decoration: InputDecoration(
                hintText: '4-digit PIN',
                counterText: '',
                errorText: error,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                suffixIcon: IconButton(
                  icon: Icon(
                    obscure ? Icons.visibility : Icons.visibility_off,
                  ),
                  onPressed: () =>
                      setState(() => obscure = !obscure),
                ),
              ),
              onSubmitted: (_) => submit(),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'Cancel',
                  style: AmagamaTypography.buttonStyle.copyWith(
                    color: AmagamaColors.textSecondary,
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AmagamaColors.secondary,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  'OK',
                  style: AmagamaTypography.buttonStyle.copyWith(
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          );
        },
      );
    },
  );
}
