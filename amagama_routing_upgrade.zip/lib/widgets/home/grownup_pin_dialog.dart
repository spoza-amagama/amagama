// 📄 lib/widgets/home/grownup_pin_dialog.dart
//
// 🔒 GrownUpPinDialog — simple 4-digit PIN gate used
// from the Home screen before navigating to GrownupsScreen.
// ------------------------------------------------------------

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:amagama/theme/index.dart';

class GrownUpPinDialog extends StatefulWidget {
  const GrownUpPinDialog({super.key});

  @override
  State<GrownUpPinDialog> createState() => _GrownUpPinDialogState();
}

class _GrownUpPinDialogState extends State<GrownUpPinDialog> {
  final TextEditingController _pinController = TextEditingController();
  String _storedPin = '1234';
  String? _errorText;
  bool _obscure = true;

  @override
  void initState() {
    super.initState();
    _loadPin();
  }

  Future<void> _loadPin() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _storedPin = prefs.getString('grownup_pin') ?? '1234';
    });
  }

  void _submit() {
    final entered = _pinController.text.trim();
    if (entered == _storedPin) {
      Navigator.of(context).pop(true);
    } else {
      setState(() {
        _errorText = 'Incorrect PIN. Try again.';
      });
    }
  }

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFFFFF8E1),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      title: const Text(
        'Enter Parental PIN',
        style: AmagamaTypography.sectionTitleStyle,
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'This area is for grown ups only.',
            style: AmagamaTypography.bodyStyle,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _pinController,
            keyboardType: TextInputType.number,
            obscureText: _obscure,
            maxLength: 4,
            decoration: InputDecoration(
              hintText: '4-digit PIN',
              counterText: '',
              errorText: _errorText,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              suffixIcon: IconButton(
                icon: Icon(
                  _obscure ? Icons.visibility : Icons.visibility_off,
                ),
                onPressed: () {
                  setState(() {
                    _obscure = !_obscure;
                  });
                },
              ),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: Text(
            'Cancel',
            style: AmagamaTypography.buttonStyle.copyWith(
              color: AmagamaColors.textSecondary,
            ),
          ),
        ),
        ElevatedButton(
          onPressed: _submit,
          style: ElevatedButton.styleFrom(
            backgroundColor: AmagamaColors.secondary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            'Enter',
            style: AmagamaTypography.buttonStyle.copyWith(
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }
}
