// 📄 lib/widgets/app/index.dart
// Barrel file for app-level widgets.

export 'amagama_app.dart';