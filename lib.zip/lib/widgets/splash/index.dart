// 📄 lib/widgets/splash/index.dart
// Barrel for splash-related widgets.

export 'splash_screen.dart';
export 'animated_splash_screen.dart';