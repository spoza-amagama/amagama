// 📄 lib/widgets/play/play_layout.dart
// 📌 Stateless composition of the Play screen UI
// ✅ Encapsulates Scaffold structure and layered widgets (app bar, body, overlays)

import 'package:flutter/material.dart';
import 'package:amagama/widgets/sparkle_layer.dart';
import 'package:amagama/widgets/play/index.dart';

class PlayLayout extends StatelessWidget {
  final AnimationController pulse;
  final GlobalKey<SparkleLayerState> sparkleKey;

  const PlayLayout({
    super.key,
    required this.pulse,
    required this.sparkleKey,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const PlayAppBar(),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Main game content
          PlayBody(pulse: pulse),

          // Sparkles overlay (non-interactive)
          Positioned.fill(
            child: IgnorePointer(
              ignoring: true,
              child: SparkleLayer(key: sparkleKey),
            ),
          ),

          // Audio <-> Game state bridge
          const AudioStateBridge(),

          // Loading overlay (e.g., while preparing audio/assets)
          const LoadingOverlay(),
        ],
      ),
    );
  }
}
