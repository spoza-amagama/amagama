// 📄 lib/screens/play_screen.dart
// 📌 Orchestrator for the Play flow
// ✅ Hosts controllers + dialog handling and delegates UI to PlayLayout

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:amagama/state/game_controller.dart';
import 'package:amagama/widgets/sparkle_layer.dart';
import 'package:amagama/widgets/play/index.dart';

class PlayScreen extends StatefulWidget {
  const PlayScreen({super.key});

  @override
  State<PlayScreen> createState() => _PlayScreenState();
}

class _PlayScreenState extends State<PlayScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;
  final GlobalKey<SparkleLayerState> _sparkleKey = GlobalKey<SparkleLayerState>();
  bool _showingEndDialog = false;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
      lowerBound: 0.9,
      upperBound: 1.05,
    );

    // Optional: start a subtle breathing-like pulse
    _pulse.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _pulse.reverse();
      } else if (status == AnimationStatus.dismissed) {
        _pulse.forward();
      }
    });
    _pulse.forward();
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Watch round-complete flag to trigger end-of-round dialog exactly once
    context.select<GameController, bool>((g) => g.isRoundComplete);
    _maybeShowEndDialog();

    return PlayLayout(
      pulse: _pulse,
      sparkleKey: _sparkleKey,
    );
  }

  void _maybeShowEndDialog() {
    final game = context.read<GameController>();
    if (!mounted) return;

    if (game.isRoundComplete && !_showingEndDialog) {
      _showingEndDialog = true;

      showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => CompletionDialog(
          onNext: () {
            Navigator.of(ctx).pop();
            game.advanceOrFinish();
            _showingEndDialog = false;
          },
          onRepeat: () {
            Navigator.of(ctx).pop();
            game.repeatRound();
            _showingEndDialog = false;
          },
        ),
      );
    }
  }
}
