// 📄 lib/widgets/play/sentence_stack.dart
// Program Description:
// Presents the animated sentence with a sparkle overlay in a finite,
// predictable space to avoid unbounded Stack errors in Column layouts.

import 'package:flutter/material.dart';
import 'package:amagama/widgets/sentence_header.dart';
import 'package:amagama/widgets/sparkle_layer.dart';

/// ✨ SentenceStack
/// Combines the sentence header animation and sparkle overlay inside
/// a fixed-height box so parents (e.g., Column) provide finite constraints.
class SentenceStack extends StatelessWidget {
  final String text;
  final AnimationController controller;
  final GlobalKey<SparkleLayerState> sparkleKey;

  /// Optional fixed height for the band that shows the animated sentence.
  /// Defaults to 160 for good balance on phones/tablets/desktops.
  final double height;

  const SentenceStack({
    super.key,
    required this.text,
    required this.controller,
    required this.sparkleKey,
    this.height = 160,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height, // ✅ finite constraints
      width: double.infinity,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SentenceHeader(text: text, controller: controller),
          Positioned.fill(
            child: IgnorePointer(
              ignoring: true,
              child: SparkleLayer(key: sparkleKey),
            ),
          ),
        ],
      ),
    );
  }
}
